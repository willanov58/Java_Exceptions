import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class UserDataApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите данные в формате: Фамилия Имя Отчество Датарождения Номертелефона Пол");
        String input = scanner.nextLine();
        scanner.close();

        String[] data = input.split(" ");
        if (data.length != 6) {
            System.err.println("Ошибка: Введено неверное количество данных.");
            return;
        }

        try {
            String lastName = data[0];
            String firstName = data[1];
            String middleName = data[2];
            String birthDate = validateDate(data[3]);
            long phoneNumber = validatePhoneNumber(data[4]);
            char gender = validateGender(data[5]);

            String userData = String.format("<%s><%s><%s><%s><%d><%c>", lastName, firstName, middleName, birthDate, phoneNumber, gender);
            writeToFile(lastName, userData);
        } catch (IllegalArgumentException e) {
            System.err.println("Ошибка: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Ошибка при работе с файлом:");
            e.printStackTrace();
        }
    }

    private static String validateDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(date);
            return date;
        } catch (ParseException e) {
            throw new IllegalArgumentException("Неверный формат даты рождения. Ожидается dd.mm.yyyy");
        }
    }

    private static long validatePhoneNumber(String phoneNumber) {
        try {
            return Long.parseLong(phoneNumber);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Неверный формат номера телефона. Ожидается целое беззнаковое число");
        }
    }

    private static char validateGender(String gender) {
        if (gender.length() == 1 && (gender.charAt(0) == 'f' || gender.charAt(0) == 'm')) {
            return gender.charAt(0);
        } else {
            throw new IllegalArgumentException("Неверный формат пола. Ожидается 'f' или 'm'");
        }
    }

    private static void writeToFile(String lastName, String userData) throws IOException {
        File file = new File(lastName + ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(userData);
            writer.newLine();
        }
    }
}